#include <msp430.h>
#include <stdlib.h>
#include "peripherals.h"

#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)



//Function Prototype
void TimerA2run();
void TimerA2stop();
void TimerCount(int time);

unsigned long int count = 2305716;
unsigned long int currcount = 0;
unsigned char *temp,*date;
volatile unsigned long int timecopy;
volatile unsigned int tempval;
volatile unsigned int potval = 0;
unsigned char buzz=0;
float Ctemp, tempcopy;
long times[256];
float tempC[256];
void main(void)
{
    volatile unsigned int bits30, bits85;
    unsigned char button, inc;
    WDTCTL = WDTPW | WDTHOLD;
    _BIS_SR(GIE);

    configDisplay();
    configButtons();
    Graphics_clearDisplay(&g_sContext);


    bits30 = CALADC12_15V_30C;
    bits85 = CALADC12_15V_85C;
    float Cpb = (float) (85.0-30.0) /(float) (bits85-bits30);

    TimerA2run();

    P6SEL |= BIT0;

    REFCTL0 &= ~REFMSTR;

    ADC12CTL0 = ADC12SHT0_9 | ADC12REFON | ADC12ON | ADC12MSC;
    ADC12CTL1 = ADC12SHP | ADC12CONSEQ_1 | ADC12CSTARTADD_0;
    ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_10;
    ADC12MCTL1 = ADC12SREF_0 + ADC12INCH_0 + ADC12EOS;

    ADC12CTL0 &= ~ADC12SC;

    ADC12IE = ADC12IE0 | ADC12IE1;


    while (1)
    {
        timecopy=count;
        date=displayTime(timecopy);

        Ctemp = (float)((long)tempval-CALADC12_15V_30C)*Cpb + 30;

        tempcopy=Ctemp;
        temp = displayTemp(tempcopy);

        Graphics_drawStringCentered(&g_sContext, date, 15, 48, 35, OPAQUE_TEXT);
        Graphics_drawStringCentered(&g_sContext, temp, 16, 48, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
        if (inButton()!=0) button = inButton();
        if (button == 1) BuzzerMode(potval);
        if (button == 2) BuzzerOff();
        if(count%3600 == 0)
        {
            buzz=0;
            BuzzerOn();
            if (buzz<4)
                buzz++;
            else if(buzz==4)
            {
                BuzzerOff();
                buzz=0;
            }
        }
    }
}


void TimerA2run()
{
    TA2CTL = TASSEL_1 + MC_1 + ID_0;
    TA2CCR0 = 32767;
    TA2CCTL0 = CCIE;
}

void TimerA2stop(int reset)
{
    TA2CTL = MC_0;
    TA2CCTL0 &= ~CCIE;
    if (reset)
        {count = 2305716;
        currcount = 0;}
}


#pragma vector = TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR (void)
{
    ADC12CTL0 &= ~ADC12SC;
    ADC12CTL0 |= (ADC12SC |ADC12ENC);
    count++;
}

#pragma vector = ADC12_VECTOR
__interrupt void adc12_ISR(void)
{
    tempval = ADC12MEM0 & 0x0FFF;
    potval = ADC12MEM1 & 0x0FFF;
}
