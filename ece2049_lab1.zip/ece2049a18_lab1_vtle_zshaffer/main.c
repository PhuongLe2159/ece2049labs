#include <msp430.h>
#include <stdlib.h>
#include "peripherals.h"

#define SIZE 32

void swDelay(char numLoops);
//void swDelay(char numLoops);

void main(void)
{
    unsigned int state = 0;
    unsigned char currKey = 0;
    WDTCTL = WDTPW | WDTHOLD;
    initLeds();
    configDisplay();
    configKeypad();
    Graphics_clearDisplay(&g_sContext);

    while (1)
    {
        switch(state)
        {
            case 0:         //Welcome screen
            {
                Graphics_clearDisplay(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "ECE2049 SIMON", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
                Graphics_drawStringCentered(&g_sContext, "Press * to start", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                while (state == 0)
                {
                    if (getKey()=='*') state = 1;
                }
                break;
            }

            case 1:         //The game
            {
                Graphics_clearDisplay(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "3", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay(20);
                 Graphics_clearDisplay(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "2", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay(20);
                Graphics_clearDisplay(&g_sContext);
                Graphics_drawStringCentered(&g_sContext, "1", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
                Graphics_flushBuffer(&g_sContext);
                swDelay(20);
                Graphics_clearDisplay(&g_sContext);

                unsigned char LEDs[SIZE];
                int i=0, j=0, total=0, win = 1;

                for (i=0;i<SIZE;i++)
                    LEDs[i]=rand() % 4 +1;
                while (total<SIZE)
                {
                    for (j=0;j<=total;j++)
                    {
                        LedOn(LEDs[j]);                 //Function written in Peripherals.c
                        BuzzerMode(LEDs[j]);            //Function written in Peripherals.c
                        swDelay((int)SIZE/(total+1));
                        setLeds(0);
                        BuzzerOff();
                        swDelay((int)SIZE/(total+1));
                    }
                    Graphics_clearDisplay(&g_sContext);
                    Graphics_drawStringCentered(&g_sContext, "Go!", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
                    Graphics_flushBuffer(&g_sContext);
                    swDelay(10);
                    Graphics_clearDisplay(&g_sContext);
                    for (i=0;i<=total;i++)
                    {
                        while (currKey == 0) currKey = getKey();
                        while (currKey==getKey()) ;

                        if ((currKey - 0x30) == LEDs[i])
                        {
                            Graphics_clearDisplay(&g_sContext);
                            char disp[1]= currKey;
                            Graphics_drawStringCentered(&g_sContext,disp,1, 24 * (currKey-0x30)-10, 35, TRANSPARENT_TEXT);
                            Graphics_flushBuffer(&g_sContext);
                            currKey = 0;
                        }
                        else
                        {
                            win = 0;
                            currKey = 0;
                            break;
                        }
                        //swDelay(2);


                    }
                    if (win == 0) break;
                    total++;
                }
                switch(win)     //Check if player win or lose
                {
                case 0:         //Lose
                {
                    Graphics_clearDisplay(&g_sContext);
                    Graphics_drawStringCentered(&g_sContext,"GAME OVER",AUTO_STRING_LENGTH,48, 35, TRANSPARENT_TEXT);
                    Graphics_flushBuffer(&g_sContext);
                    swDelay(20);
                    break;
                }
                default:        //Win
                {
                    Graphics_clearDisplay(&g_sContext);
                    Graphics_drawStringCentered(&g_sContext,"YOU WIN!!!",AUTO_STRING_LENGTH,48, 35, TRANSPARENT_TEXT);
                    Graphics_flushBuffer(&g_sContext);
                    swDelay(20);
                    break;
                }
                }
                state=0;
                break;
            }
        }
    }

}


void swDelay(char numLoops)
{
    // This function is a software delay. It performs
    // useless loops to waste a bit of time
    //
    // Input: numLoops = number of delay loops to execute
    // Output: none
    //
    // smj, ECE2049, 25 Aug 2013

    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code

    for (j=0; j<numLoops; j++)
    {
        i = 5000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}
