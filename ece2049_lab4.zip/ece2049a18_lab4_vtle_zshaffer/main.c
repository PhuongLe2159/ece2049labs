#include <msp430.h>
#include <stdlib.h>
#include "peripherals.h"

#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)



//Function Prototype
void TimerA2run();
void TimerA2SMCLKrun(int time);
void TimerA2stop();
void TimerCount(int time);

unsigned long int count = 0;
unsigned long int currcount = 0;
volatile unsigned long int timeval;
volatile unsigned int potval = 0,voltval = 0;
unsigned char buzz=0;

unsigned int dac[14] = {0,585,1170,1755,2340,2925,3510,4095,3510,2925,2340,1755,1170,585};
unsigned int val[10] = {500,1000,1500,2000,2500,3000,3500,4000,4050,4095};
float voltrecDAC[10],voltrecADC[10];
void linearity(unsigned char num);

void main(void)
{
    volatile unsigned int bits30, bits85;
    unsigned char button, state = 0,currkey;
    unsigned int triangle = 0, step = 0;
    WDTCTL = WDTPW | WDTHOLD;
    _BIS_SR(GIE);

    configDisplay();
    configButtons();
    configKeypad();
//    setupSPI_DAC();
    DACInit();
    Graphics_clearDisplay(&g_sContext);


//    P6SEL |= BIT0;
    P6SEL |= BIT1;
    REFCTL0 &= ~REFMSTR;

//    ADC12CTL0 = ADC12SHT0_9 | ADC12ON;
//    ADC12CTL1 = ADC12SHP;
//    ADC12MCTL0 = ADC12SREF_0 + ADC12INCH_0;


        ADC12CTL0 = ADC12SHT0_9 | ADC12ON;
        ADC12CTL1 = ADC12SHP;
        ADC12MCTL0 = ADC12SREF_0 + ADC12INCH_1;
    ADC12CTL0 &= ~ADC12SC;

//    ADC12IE = ADC12IE0;
    ADC12CTL0 &= ~ADC12SC;

    unsigned char i=0;
    while (1)
    {
        linearity(i%10);
        ADC12CTL0 |= (ADC12SC |ADC12ENC);
        while (ADC12CTL1 & ADC12BUSY) _no_operation();
        voltval= ADC12MEM0 & 0x0FFF;
        ADC12CTL0 &= ~ADC12SC;
        voltrecADC[i%10]=(float)voltval*3.3/4095;
r        i++;
//        switch (state)
//        {
//        case 0:
//        {
//            Graphics_drawStringCentered(&g_sContext, "Function gen", AUTO_STRING_LENGTH, 48, 15, OPAQUE_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "1 = DC", AUTO_STRING_LENGTH, 48, 25, OPAQUE_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "2 = Square", AUTO_STRING_LENGTH, 48, 35, OPAQUE_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "3 = Sawtooth", AUTO_STRING_LENGTH, 48, 45, OPAQUE_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "4 = Triangle", AUTO_STRING_LENGTH, 48, 55, OPAQUE_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "5 = Linearity", AUTO_STRING_LENGTH, 48, 65, OPAQUE_TEXT);
//            Graphics_flushBuffer(&g_sContext);
//            currkey=getKey();
//            count=0;
//            switch(currkey)
//            {
//                case '1':
//                {
//                    state = 1;
//                    timeval=32767;
//                    TimerA2run(timeval);
//                    break;
//                }
//                case '2':
//                {
//                    state = 2;
//                    timeval=204;
//                    TimerA2run(timeval);
//                    break;
//                }
//                case '3':
//                {
//                    state = 3;
////                    timeval = 20;
////                    step =(int) 4095/timeval;
//                    timeval = 20;
//                    step = 195;
//                    TimerA2run(timeval);
//                    break;
//                }
//                case '4':
//                {
//                    state = 4;
//                    timeval = 373;
//                    step = 532;
//                    TimerA2SMCLKrun(timeval);
//                    triangle = 0;
//                    break;
//                }
////                case '5':
////                {
////                    state = 5;
////                    timeval = potval;
////                    step = 532;
////                    TimerA2SMCLKrun(timeval);
////                    triangle = 0;
////                    break;
////                }
//                default:
//                {
//                    state = 0;
//                    break;
//                }
//            }
//            currcount=count;
//            break;
//        }
//
//        case 1:
//        {
//            DACSetValue(potval);
////            DACSetValue(4095);
////            DACSetValue(0);
//            if (getKey()=='#')
//            {
//                state = 0;
//                TimerA2stop(1);
//            }
//            else
//                state = 1;
//            break;
//        }
//
//        case 2:
//        {
//            while (currcount == count) _no_operation();
//            currcount=count;
//            DACSetValue(potval*(currcount % 2));
//            if (getKey()=='#')
//            {
//                state = 0;
//                TimerA2stop(1);
//            }
//            else
//                state = 2;
//            break;
//        }
//
//        case 3:
//        {
//            unsigned int volt;
//            while (currcount == count) ;
//            volt = (count % timeval)*step;
//            DACSetValue(volt);
//            currcount = count;
//            if (getKey()=='#')
//            {
//                state = 0;
//                TimerA2stop(1);
//            }
//            else
//                state = 3;
//            break;
//        }
//
//        case 4:
//        {
//            //100 steps/cycle
//            while (currcount == count) _no_operation();
////            {
//                currcount = count;
//            DACSetValue(dac[count%14]);
////            }
//            if (getKey() == '#')
//            {
//                state = 0;
//                TimerA2stop(1);
//            }
//            else
//                state = 4;
//            break;
//        }
//
////        case 5:
////        {
////            TA2CCR0 = (int)(potval*2.5);
////            while (currcount == count) _no_operation();
////                currcount = count;
////            DACSetValue(dac[count%14]);
////            if (getKey() == '#')
////            {
////                state = 0;
////                TimerA2stop(1);
////            }
////            else
////                state = 5;
////            break;
////        }
//        case '5':
//
//        }

    }
}


void TimerA2run(int time)
{
    TA2CTL = TASSEL_1 + MC_1 + ID_0;
    TA2CCR0 = time;
    TA2CCTL0 = CCIE;
}


void TimerA2SMCLKrun(int time)
{
    TA2CTL = TASSEL_2 + MC_1 + ID_1;
    TA2CCR0 = time;
    TA2CCTL0 = CCIE;
}

void TimerA2stop(int reset)
{
    TA2CTL = MC_0;
    TA2CCTL0 &= ~CCIE;
    if (reset)
        {count = 0;
        currcount = 0;}
}

void linearity(unsigned char num)
{
    float out;

        DACSetValue(val[num]);
        voltrecDAC[num]=(float)val[num]*3.3/4095;

}

#pragma vector = TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR (void)
{
//    ADC12CTL0 &= ~ADC12SC;
//    ADC12CTL0 |= (ADC12SC |ADC12ENC);
    count++;
}
//
//#pragma vector = ADC12_VECTOR
//__interrupt void adc12_ISR(void)
//{
////    potval = ADC12MEM0 & 0x0FFF;
//    voltval= ADC12MEM1 & 0x0FFF;
//}
