/**************  ECE2049 LAB 02   ******************/
/**************  22 August 2018   ******************/
/***************************************************/

#include <msp430.h>
#include <stdio.h>
#include <stdlib.h>
#include "peripherals.h"

int MAX_NOTES=300;

enum Length {Whole=16,HalfH=12,Half=8,QuartH=6,Quart=4,EightH=3,Eighth=2,Sixteenth=1};

enum Notes {C0=65,Cs0=69,D0=73,Ds0=78,E0=82,F0=87,Fs0=93,G0=98,Gs0=104,A0=110,As0=117,B0=123,
            C1=131,Cs1=139,D1=147,Ds1=156,E1=165,F1=175,Fs1=185,G1=196,Gs1=208,A1=220,As1=233,B1=247,
            C2=262,Cs2=277,D2=294,Ds2=311,E2=330,F2=349,Fs2=370,G2=392,Gs2=415,A2=440,As2=466,B2=494,
            C3=523,Cs3=554,D3=587,Ds3=622,E3=659,F3=698,Fs3=740,G3=784,Gs3=831,A3=880,As3=932,B3=988,C4=1047};

enum Difficulty {Easy=250,Medium=200,Hard=150,Deadly=100};

// Function Prototypes
void TimerA2run();
void TimerA2stop();
void TimerCount(int time);
int TimeCheck(int time, int leds);
// Declare globals here

//int pitch[MAX_NOTES]={Cs1,Ds1,Gs0,Ds1,F1,Gs1,Fs1,F1,Ds1,Cs1,Ds1,Gs0,Gs0,Gs0,Gs0,As0,Cs1,Cs1,Ds1,Gs0,Ds1,F1,Gs1,Fs1,F1,Ds1,Cs1,Ds1,Gs0,Gs0};

//int length[MAX_NOTES]={QuartH,QuartH,Quart,QuartH,QuartH,Sixteenth,Sixteenth,Sixteenth,Sixteenth,QuartH,QuartH,Quart,QuartH,Sixteenth,Sixteenth,Sixteenth,Eighth,QuartH,QuartH,Quart,QuartH,QuartH,Sixteenth,Sixteenth,Sixteenth,Sixteenth,QuartH,QuartH,Quart,QuartH};

//Fs3,E3,D3,Cs3,D2,Fs3,E3,B2,A2,A2,
//             D3,A2,B2,Cs3,Fs2,Fs2,B2,A2,G2,A2,D2,D2,E2,E2,Fs2,G2,G2,A2,
//             B2,Cs3,D3,E3,Fs3,E3,D3,E3,Cs3,A2,D3,Cs3,B2,Cs3,Fs2,Fs2,B2,A2,G2,A2,D2,D2,
//             D3,Cs3,B2,A2,Cs3,D3,E3,Fs3,E3,D3,Cs3,D3,E3,A2,A2,Cs3,D3,E3,
//             D3,Cs3,B2,A2,B2,Cs3,Fs2,Fs2,A2,B2,Cs3,D3,B2,Cs3,D3,B2,Cs3,D3,B2,D3,G3,
//             G3,Fs3,E3,D3,E3,Fs3,D3,D3,E3,D3,Cs3,B2,Cs3,D3,B2,B2,

//Quart,EightH,Sixteenth,Quart,Quart,Quart,EightH,Sixteenth,Quart,Quart,
//              Eighth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,Eighth,Eighth,Quart,Eighth,Eighth,
//              Quart,Eighth,Eighth,Half,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,EightH,Sixteenth,
//              Quart,EightH,Sixteenth,Eighth,Eighth,Eighth,Eighth,Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Eighth,Eighth,Eighth,Eighth,
//              Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Eighth,Eighth,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Half,
//              Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Half,Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Half,

int pitch[]={A2,D3,A2,B2,Cs3,Fs2,Fs2,B2,A2,G2,A2,D2,D2,E2,E2,Fs2,G2,G2,A2,
             B2,Cs3,D3,E3,Fs3,E3,D3,E3,Cs3,A2,D3,Cs3,B2,Cs3,Fs2,Fs2,B2,A2,G2,A2,D2,D2,
             D3,Cs3,B2,A2,Cs3,D3,E3,Fs3,E3,D3,Cs3,D3,E3,A2,A2,Cs3,D3,E3,
             D3,Cs3,B2,A2,B2,Cs3,Fs2,Fs2,A2,B2,Cs3,D3,B2,Cs3,D3,B2,Cs3,D3,B2,D3,G3,
             G3,Fs3,E3,D3,E3,Fs3,D3,D3,E3,D3,Cs3,B2,Cs3,D3,B2,B2,
             D3,Cs3,B2,A2,D2,A2,B2,Cs3,D3};

int length[]={Eighth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,Eighth,Eighth,Quart,Eighth,Eighth,
              Quart,Eighth,Eighth,Half,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,EightH,Sixteenth,
              Quart,EightH,Sixteenth,Eighth,Eighth,Eighth,Eighth,Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Eighth,Eighth,Eighth,Eighth,
              Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Eighth,Eighth,Eighth,Eighth,Quart,EightH,Sixteenth,Quart,EightH,Sixteenth,Quart,Eighth,Eighth,Half,
              Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Half,Half,Eighth,Eighth,Eighth,Eighth,QuartH,Eighth,Half,
              Quart,EightH,Sixteenth,Quart,Quart,Quart,Eighth,Eighth,Half};


struct Songs
{
    int pitches[200];
    float duration[200];
}song;


unsigned long int count = 0;
unsigned long int currcount = 0;

// Main
void main(void)
{
    _BIS_SR(GIE);
    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                 // You can then configure it properly, if desired
    unsigned char state=0;
    int num = 0,check=1;
    int hardness = Medium;
//    unsigned char button;
    unsigned char error=0;
    //________________________________________________________________________________________

    //Init Stuff
    initLeds();
    configDisplay();
    configKeypad();
    configButtons();
    //________________________________________________________________________________________

    while (1)    // Forever loop
    {
        switch(state)
        {
        case 0: //Welcome screen
        {
            Graphics_clearDisplay(&g_sContext); // Clear the display
            Graphics_drawStringCentered(&g_sContext, "MSP430 Hero", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT);
            Graphics_drawStringCentered(&g_sContext, "Press * to start", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            while (getKey() != '*') ;

//            #ifdef MAX_NOTES
//            #undef MAX_NOTES
//            #endif
//
//            #define MAX_NOTES (sizeof(pitch)/sizeof(pitch[0]))
            MAX_NOTES =(int) (sizeof(pitch)/sizeof(pitch[0]));

            state = 2;
            break;
        }
//
//        case 1: //Select song
//        {
//            Graphics_clearDisplay(&g_sContext); // Clear the display
//            Graphics_drawStringCentered(&g_sContext, "Select songs", AUTO_STRING_LENGTH, 48, 15, TRANSPARENT_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "1.NeverGonnaGiveUUp", AUTO_STRING_LENGTH, 48, 25, TRANSPARENT_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "2.TakeOnMe", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "3.MarioThemeSong", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
//            Graphics_drawStringCentered(&g_sContext, "4.", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
//            Graphics_flushBuffer(&g_sContext);
//        }
        case 2: //Set song
        {
            int i=0;
            for (i=0;i<MAX_NOTES;i++)
            {
                song.pitches[i]=pitch[i];
                song.duration[i]=length[i];
            }
            state = 3;
            break;
        }
        case 3: //Countdown
        {
            TimerA2run();
            setLeds(0);
            BuzzerMode(C3);
            Graphics_clearDisplay(&g_sContext);
            Graphics_drawStringCentered(&g_sContext, "3", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            LedOn(3);
            TimerCount(200);
            setLeds(0);
            BuzzerMode(D3);
            Graphics_clearDisplay(&g_sContext);
            Graphics_drawStringCentered(&g_sContext, "2", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            LedOn(2);
            TimerCount(200);
            setLeds(0);
            BuzzerMode(E3);
            Graphics_clearDisplay(&g_sContext);
            Graphics_drawStringCentered(&g_sContext, "1", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            LedOn(1);
            TimerCount(200);
            setLeds(0);
            BuzzerMode(G3);
            Graphics_clearDisplay(&g_sContext);
            Graphics_drawStringCentered(&g_sContext, "Go!", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            setLeds(15);
            TimerCount(200);
            setLeds(0);
            Graphics_clearDisplay(&g_sContext);
            BuzzerOff();
            state = 4;
            break;
        }

        case 4:     //Main game
        {
            if(num == MAX_NOTES)
            {
                num = 0;
                state = 6;
                break;
            }
            else
            {
                if (getKey() == '#')
                {
                    state = 0;
                    break;
                }
                BuzzerMode(song.pitches[num]);
                setLeds(song.pitches[num]%10+1);
//                TimerCount(100*song.duration[num]);
                check=TimeCheck((int)hardness*song.duration[num]/4,song.pitches[num]%10+1);
                BuzzerOff();
                setLeds(0);
                if (check == 0)
                {
                    configUserLED(2);
                    check = 1;
                    error++;
                }
                else
                    configUserLED(1);
//                if (error==3)
//                {
//                    configUserLED(0);
//                    num=0;
//                    error=0;
//                    state = 5;
//                    break;
//                }
                num++;
                state = 4;
                break;
            }
//            button=inButton();
//            char disp[1]=button+0x30;
//            Graphics_clearDisplay(&g_sContext);
//            Graphics_drawStringCentered(&g_sContext, disp, 1, 48, 45, TRANSPARENT_TEXT);
//            Graphics_flushBuffer(&g_sContext);
//            state = 4;
//            break;
        }

        case 5:     //Lose
        {
            BuzzerMode(C0);
            Graphics_clearDisplay(&g_sContext);
            Graphics_drawStringCentered(&g_sContext, "Boooooo", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_drawStringCentered(&g_sContext, "Loser!", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT);
            BuzzerOff();
            Graphics_flushBuffer(&g_sContext);
            TimerCount(200);
            state = 0;
            break;
        }

        case 6:     //Win
        {
            Graphics_clearDisplay(&g_sContext);
            Graphics_drawStringCentered(&g_sContext, "Awesome", AUTO_STRING_LENGTH, 48, 35, TRANSPARENT_TEXT);
            Graphics_drawStringCentered(&g_sContext, "You Nailed It", AUTO_STRING_LENGTH, 48, 45, TRANSPARENT_TEXT);
            Graphics_flushBuffer(&g_sContext);
            TimerCount(200);
            state = 0;
            break;
        }
        }
    }  // end while (1)
}


void TimerA2run()
{
    TA2CTL = TASSEL_1 + MC_1 + ID_0;
    TA2CCR0 = 163;
    TA2CCTL0 = CCIE;
}

void TimerA2stop(int reset)
{
    TA2CTL = MC_0;
    TA2CCTL0 &= ~CCIE;
    if (reset)
        {count = 0;
        currcount = 0;}
}

void TimerCount(int time)
{
    currcount = count;
    while (count-currcount<time);
}


int TimeCheck(int time, int leds)
{
    int b = 0;
    currcount=count;
    while (count-currcount<time)
    {
        char button=inButton();
//        char disp[1]=button+0x30;
//        Graphics_clearDisplay(&g_sContext);
//        Graphics_drawStringCentered(&g_sContext, disp, 1, 48, 45, TRANSPARENT_TEXT);
//                    Graphics_flushBuffer(&g_sContext);
        if (button && button==leds) b=1;
    }
    return b;
}

#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR (void)
{
    count++;
}
